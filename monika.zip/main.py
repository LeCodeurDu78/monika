"""
main.py
--------
Point d'entrée du programme Monika.
"""

from agent import run_monika_voice

if __name__ == "__main__":
    run_monika_voice()